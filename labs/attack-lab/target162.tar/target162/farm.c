/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_444()
{
    return 3267856712U;
}

unsigned getval_310()
{
    return 3284633928U;
}

unsigned getval_133()
{
    return 2438522460U;
}

unsigned addval_143(unsigned x)
{
    return x + 3281031288U;
}

unsigned addval_406(unsigned x)
{
    return x + 3284633928U;
}

void setval_431(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_316(unsigned x)
{
    return x + 3281017005U;
}

unsigned addval_264(unsigned x)
{
    return x + 2425378921U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_187()
{
    return 2464188744U;
}

unsigned getval_421()
{
    return 3286272328U;
}

unsigned getval_419()
{
    return 3281047049U;
}

void setval_181(unsigned *p)
{
    *p = 2425471625U;
}

unsigned addval_386(unsigned x)
{
    return x + 2445445618U;
}

unsigned addval_409(unsigned x)
{
    return x + 3285289317U;
}

unsigned getval_261()
{
    return 3281047169U;
}

unsigned getval_495()
{
    return 3683962505U;
}

void setval_382(unsigned *p)
{
    *p = 3767101564U;
}

unsigned addval_226(unsigned x)
{
    return x + 2447411528U;
}

void setval_199(unsigned *p)
{
    *p = 2425537161U;
}

void setval_354(unsigned *p)
{
    *p = 2425668233U;
}

unsigned addval_124(unsigned x)
{
    return x + 3676357259U;
}

unsigned addval_327(unsigned x)
{
    return x + 3523792393U;
}

unsigned getval_241()
{
    return 3380924841U;
}

void setval_413(unsigned *p)
{
    *p = 3373846921U;
}

unsigned getval_198()
{
    return 3264270729U;
}

unsigned getval_389()
{
    return 2497743176U;
}

void setval_259(unsigned *p)
{
    *p = 3534016137U;
}

void setval_480(unsigned *p)
{
    *p = 3385119113U;
}

unsigned addval_377(unsigned x)
{
    return x + 3224948361U;
}

unsigned getval_293()
{
    return 3674263177U;
}

void setval_112(unsigned *p)
{
    *p = 3767093296U;
}

unsigned addval_145(unsigned x)
{
    return x + 3372794505U;
}

unsigned addval_234(unsigned x)
{
    return x + 2425471625U;
}

unsigned addval_175(unsigned x)
{
    return x + 3527987593U;
}

void setval_278(unsigned *p)
{
    *p = 3523789449U;
}

unsigned addval_438(unsigned x)
{
    return x + 3526939081U;
}

void setval_331(unsigned *p)
{
    *p = 2497743176U;
}

void setval_333(unsigned *p)
{
    *p = 3771287703U;
}

unsigned getval_129()
{
    return 3526938249U;
}

unsigned addval_110(unsigned x)
{
    return x + 3221803401U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
